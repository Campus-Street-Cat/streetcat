## 2021 - 1 항공대학교 모바일 SW 스튜디오
## 캠퍼스 길고양이 팀
![image](https://user-images.githubusercontent.com/52690419/112317412-5e2cd180-8cef-11eb-9c2f-d9d4dc791271.png)


### 개발 배경
우리 학교 길고양이들 어디 자랑할 곳 없을까?


### 사용 기술
Kotlin

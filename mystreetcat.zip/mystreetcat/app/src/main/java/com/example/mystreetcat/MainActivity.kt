package com.example.mystreetcat

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btn_add: Button = findViewById(R.id.btn_add);
        btn_add.setOnClickListener()
        {
            Toast.makeText(this@MainActivity, "고양이를 추가합니다.", Toast.LENGTH_SHORT).show()

            val intent = Intent(this, CatActivity::class.java); //화면이동
            startActivity(intent);
        }
    }
}